<?php 
header('Location: http://localhost/jrproperty/public/');
?>

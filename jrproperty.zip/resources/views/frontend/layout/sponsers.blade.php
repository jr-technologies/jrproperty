<div class="container">
			 <div class="row">
                      <div class="col-md-12">
                          <div class="titles">
                            
                              <h1>OUR CLIENTS</h1>
                          </div>
                      </div>
                    </div>
                <ul class="sponsors">
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/1.png") }}" alt="Image"></a></li>
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/2.png") }}" alt="Image"></a></li>
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/3.png") }}" alt="Image"></a></li>
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/4.png") }}" alt="Image"></a></li>
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/5.png") }}" alt="Image"></a></li>
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/3.png") }}" alt="Image"></a></li>
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/4.png") }}" alt="Image"></a></li>
                    <li data-toggle="tooltip" title data-original-title="Name Sponsor"> <a href="#"><img src="{{ asset("assets/front_end/img/sponsors/3.png") }}" alt="Image"></a></li>
                </ul>
            </div>
          </section>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Block extends Model {

	protected $table = 'blocks';
	public $timestamps = true;
	protected $fillable = array('society_id', 'name');

}
<?php
/**
 * Created by PhpStorm.
 * User: JR Tech
 * Date: 3/4/2016
 * Time: 11:28 AM
 */

namespace App\Policies;


class Policy
{

}